	.global	foo
foo:
